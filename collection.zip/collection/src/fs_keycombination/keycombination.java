package fs_keycombination;

public class keycombination {
	
	//[STRG] + [SHIFT] + [F] - Code aufr�umen
	//F11 - Software starten
	
}
