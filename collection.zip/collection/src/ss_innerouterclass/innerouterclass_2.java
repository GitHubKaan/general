package ss_innerouterclass;

public class innerouterclass_2 {
	
	int x = 1;
	
	public class innerouterclass_3 {
		
		int y = 2;
		
	}
}
