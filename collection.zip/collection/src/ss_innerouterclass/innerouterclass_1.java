package ss_innerouterclass;


public class innerouterclass_1 {
	public static void main(String[] args) {
		
		innerouterclass_2 outerclass = new innerouterclass_2(); //imports "innerouterclass_2" class
		
		innerouterclass_2.innerouterclass_3 innerclass = outerclass.new innerouterclass_3(); //initialisizes "innerouterclass_3" class inside "innerouterclass_2" class
		
		
		System.out.println(innerclass.y + outerclass.x); //uses variables from "innerouterclass_1 and 2"
	}
}
