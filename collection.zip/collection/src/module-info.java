module collection {
	requires java.desktop;
}