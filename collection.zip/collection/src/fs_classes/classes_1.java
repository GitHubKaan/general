package fs_classes;

public class classes_1 {
	public static void main(String[] args) {
		
		classes_2 obj1, obj2; //import "classes_2" class to use methods
		
//------------------------------ part 1 (calculate)
		obj1 = new classes_2(); //connect "obj1" with "classes_2" class method
		obj2 = new classes_2();
		
		int outp1 = obj1.meth1(100); //make "outp1" to "meth1" content and add 100
		int outp2 = obj2.meth1(200);
		
		System.out.println("Calculate result:" + outp1);
		System.out.println("Calculate result:" + outp2);
		
//------------------------------ part 2 (set/get)
		obj1.setvalue(2000); //set object value with "setvalue" method in "classes_2"
		
		System.out.println("Set/Get result:" + obj1.getvalue());

		
//------------------------------ part 2 (int to string)
		System.out.println("String result:" + obj1.tostring());

	}
}
