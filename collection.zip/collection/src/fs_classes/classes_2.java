package fs_classes;

public class classes_2 {
	
//------------------------------ part 1
	int calc1; //initialize variable
	
	public classes_2() { //class method to inizialize variables
		calc1 = 0;
	}
	
	public int meth1(int x) { //method that can be used in "classes_1"
		return x + 1 + 2; //edit content of "meth1" ("meth1" content = "x")
	}

	
//------------------------------ part 2
	public void setvalue(int v) {
		calc1 = v; //to set "calc1" value to something specific in "classes_1"
	}

	public int getvalue() {
		return calc1; //to print out value in "classes_1"
	}
	
	
//------------------------------ part 3
	public String tostring() {
		String result = Integer.toString(calc1); //integer to string
		return result;
	}
}
