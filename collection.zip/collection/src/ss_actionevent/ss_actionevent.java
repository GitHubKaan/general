package ss_actionevent;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ss_actionevent {
	public static void main(String[] args) {
		
		JFrame frame = new JFrame();
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		panel.setLayout(null);
		frame.add(panel);
		
		JButton button = new JButton();
		button.setText("action event");
		button.setBounds(50, 50, 200, 50);
		button.setVisible(true);
		panel.add(button);
		
		
		
		
		
		//different action events for different panels, frames, buttons...
		
		button.addActionListener(new ActionListener() { //first action listener for button actio
			@Override
			public void actionPerformed(ActionEvent e) { //action event
				System.out.println("button action performed");
			}
			
		});
		
		
		//es gibt auch mousemotionlistener f�r live bewegungen
		frame.addMouseListener(new MouseListener() { //second action listener for frame mouse press
			@Override
			public void mouseClicked(MouseEvent e) { //action event wenn mouse gecklickt und releasead wurde am gleichen punkt
				System.out.println("frame mouse click event performed");
				
				Point position = e.getPoint(); //wenn auf frame irg gecklickt dann werden auch die koordinaten ausgegeben
				System.out.println("Pos(X): " + position.getX() + " Pos(Y): " + position.getY());
			}
			@Override
			public void mousePressed(MouseEvent e) { //action event wenn maus einfach nur gedr�ckt wurde ohne loszulassen
			}
			@Override
			public void mouseReleased(MouseEvent e) { //action event
			}
			@Override
			public void mouseEntered(MouseEvent e) { //action event wenn man das objekt mit der maus betritt
			}
			@Override
			public void mouseExited(MouseEvent e) { //action event wenn man das objekt verl�sst mit der maus
			}
		});
	}
}
