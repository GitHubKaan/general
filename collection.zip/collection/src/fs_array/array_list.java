package fs_array;

import java.util.ArrayList;

public class array_list {
	public static void main(String[] args) {
		
		//arrays lists have no fixed amount, they are dynamic
		//the amount will automatically be increased or decreased
		
		//different types of arraylist methods:
		//	boolean add(E obj)
		//	void add(int index, E obj)
		//	Object remove(int index)
		//	Object get(int index)
		//	boolean isEmpty()
		//	int size()
		//	int indexOf (Object o)
		
		ArrayList<String> band = new ArrayList<String>(); //array-list of the type "String", "Integer" is also possible
		ArrayList<Integer> numbers = new ArrayList<Integer>(); //number array-list
		ArrayList<Double> decimalnumber = new ArrayList<Double>(); //decimal-number array-list
		
		band.add("Paul");
		band.add("Pete");
		band.add("John");
		band.add("George");
		System.out.println(band);
		
		int location = band.indexOf("Pete"); //seaching for Pete
		band.remove(location);
		
		System.out.println(band);
		System.out.println("At index 1: " + band.get(1));
		band.add(2, "Ringo");
		
		System.out.println("Size of the band; " + band.size());
		int index = 0;
		while (index < band.size()) {
			System.out.println(band.get(index));
			index++;
		}
		
		System.out.println("1. member of the band-array: " + band.get(0)); //getting the first member of the band
	}
}
