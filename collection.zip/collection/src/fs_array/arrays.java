package fs_array;

import java.util.Arrays;

public class arrays
{
	public static void main(String[] args) {
		//arrays are lists (collection)
		//example: 6 numbers (6 integers)
		
		//one array can only contain one type of variable
		//example: one array for integers, one array for strings...
		
		//arrays must be decelerated in "[, ]"
		//"[, ]" = collection
		
		//--------------------------------------------------------------------------------
		
		//creating a integer array
		int [] test;
		//set the array "test "to max 100 double elements, no more are possible to contain
		//100 arrays start at position 0 and go up to 99
		test = new int [100];
		//edit position of the array
		int a = test[5];
		//edit value of specific array position
		test[5] = 32;
		//this is how to use the 5. position in the array
		System.out.println("(test 1) array \"test\" contains " + test[5] + " on position 5");
		
		//--------------------------------------------------------------------------------
		
		//creating the array that should be contain multiple integers
		int[] list = {5, 2, 4, 3, 1, 6};
		//get length of array
		int number_of_elements = list.length;
		//sort array
		Arrays.sort(list);
		System.out.println("(test 2) total number of elemtents in \"list\": " + number_of_elements);
		System.out.println("(test 3) position 2 of the array list \"list\" contains " + list[1] + " after sorting");
		//before sort: 5, 2, 4, 3, 1, 6 (position 0 = 5, position 1 = 2...)
		//after sort:  1, 2, 3, 4, 5, 6 (position 0 = 1, position 1 = 2...)
		
		//--------------------------------------------------------------------------------
		
		int[] list_generated_sorted = new int[3];
		//create number for every slot of the integer until 4. position is reached
		for(int i = 0 ; i < 3 ; i++)
		list_generated_sorted[i] = i;


		//how to show of all elements inside the array with exact position
		for(int i = 0; i < list_generated_sorted.length; i++ )
		System.out.println("(test 4) position " + i + " contains " + list_generated_sorted[i]);

		//different way of showing array inside [ x, y, z]
		System.out.print("(test 5) ");
		System.out.println(Arrays.toString(list_generated_sorted));

		//another different way of showing array inside withoud position number
		for(int ausgabe : list_generated_sorted)
		System.out.println("(test 6) " + ausgabe);
		
		//--------------------------------------------------------------------------------

		//how to calculate the mid number from all arrays inside the list
		double[] list_to_sum = {1.1 ,1.2, 1.3};
		double collector = 0;
		double answer = 0;
		
		for (int i = 0; i < list_to_sum.length; i++)
		{
			collector = collector + list_to_sum[i];
			
			answer = collector / list_to_sum.length;
		}
		
		System.out.println("(test 7) sum of list " + answer);
		
		//--------------------------------------------------------------------------------
		
		//array matrix
		int
		[][] matrix =
		{
			{1, 0, 5, 0},
			{0, 1, 0, 0},
			{6, 0, 1, 4},
			{0, 4, 3, 1} //row 3 || section 3 = 4
		};
		
		int element = matrix[2][3]; //row 3 || section 3
		
		System.out.println("(test 8) matrix number row 3 section 3 is " + element);
		
		//--------------------------------------------------------------------------------
		
		final int N = 3;
		int[][] m = new int [N][N];
		for(int i = 0; i < N; i ++)
			for(int j = 0; j < N; j ++)
				m[i][j] = 0;

		// i 0	0	0	1	1	1	2	2	2
		// j 0	1	2	0	1	2	0	1	2
		
		//this is how the matrix would look like
		//"i" 1. row would look like: (0, 0, 0)
		//"i" 2. row would look like: (0, 0, 0)
		//"i" 3. row would look like: (0, 0, 0)
		
		final int N2 = 3;
		int[][] m2 = new int [N][N];
		for(int i2 = 0; i2 < N2; i2 ++)
			for(int j2 = 0; j2 < N2; j2 ++)
				m2[i2][j2] = i2+j2;
		
		//this is how the matrix would look like
		//"i" 1. row would look like: (0+0, 0+1, 0+2) calculatet -> (0, 1, 2)
		//"i" 2. row would look like: (1+0, 1+1, 1+2) calculatet -> (1, 2, 3)
		//"i" 3. row would look like: (2+0, 2+1, 2+2) calculatet -> (2, 3, 4)
	}
}
