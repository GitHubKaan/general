
package fs_datareadwrite;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class data_read {
	public static void main(String[] args) throws IOException //should cointain "throws IOException", exeption in java means error, IOException means imput output exeption
	{
		Scanner scan = new Scanner(new File("fs_data_datareadwrite/test.csv")); //scanning data from text file, file should be in the same folder, file can be txt or csv
		
		String row;
		
		while (scan.hasNext()) { //every is going to be scanned until there is no one left
			row = scan.nextLine(); //saving the line temporarily in variable row
			System.out.println(row);
		}
		
		//imput stream -> outside software into software
		//output stream -> outof software into data
		
		//imput: "3, 4, 5"
		//output:
		//	nextLine(): "3, 4, 5"
		//	next(): "3", "4", "5"
		
		//important scanner methods
		//String next();
		//Scanner useDelimiter(Pattern pattern)
		
		int cols = 3; //columns
		int rows = 3; //rows
		
		String [][]a = new String [cols][rows];
		
		int number = 0;
		
		while (scan.hasNext()) {
			row = scan.nextLine();
			System.out.println(row);
			
			//a[0] -> intired of first row
			
			a[number] = row.split(";"); //after what java should make a split, every number than is a individual variable (1;3 -> 13 (String1=1, String2=3))
			number++;
		}
		
			System.out.println(Arrays.toString(a[0]));
			System.out.println(Arrays.toString(a[1]));
			System.out.println(Arrays.toString(a[2]));
	}
}
