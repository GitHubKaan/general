package fs_datareadwrite;

import java.io.IOException;
import java.io.PrintWriter;

public class data_write {
	public static void main(String[] args) throws IOException //should cointain "throws IOException", exeption in java means error, IOException means imput output exeption
	{
		int amount = 10;
		int value;
		
		String fileName = "fs_data_datareadwrite/test2.csv"; //reading of "test2.csv"
		
		PrintWriter outFile = new PrintWriter("fs_data_datareadwrite/test2.csv"); //printwriter to output, ".txt" is also possible
		
		
		for (int line = 1; line <= amount; line++) { //loop to write in lines, one row -> 10 random numbers, 10 rows
			for (int num = 1; num <= amount; num++) {
				
				value = (int) (Math.random() * 90 + 10); //value==32, rand.nextInt(90)+10; -> 10 & 99
				
				outFile.print(value + " "); //spaces between the numbers
			}
		}
		outFile.close(); //closing of the process so no errors can acure
		
		System.out.println("Output file has been created: " + fileName);
	}
}
