package ss_interface;

import ss_interface.interface_1.ValueTester;

public class interface_2 implements ValueTester { //interface can be addet here "implements ValueTester"

	@Override
	public int Type1_Value() { //"non void" value will give you the option to give a return value back to the main class
		
		int number1 = 5;
		int number2 = 5;

		return number1 + number2;
	}
	
	
	@Override
	public String Type2_Value() {
		
		String string1 = "a";
		
		return string1;
	}
	

	@Override
	public void Type3_Value() {
		System.out.println("I am a void value.");
	}
}
