package ss_interface;

public class interface_1 {
	public static void main(String[] args) {
		
		interface_2 interface2 = new interface_2(); //initialisize class
		
		System.out.println(interface2.Type1_Value()); //methods with a return value can be outprinted
		System.out.println(interface2.Type2_Value());
		interface2.Type3_Value(); //void value can not be printet out with "System.out...". format should be like entered
	}
	
	
	public interface ValueTester { //name of implement. can be addit in following way: "public class [...] implements ValueTester"
		
		public int Type1_Value();
		public String Type2_Value();
		public void Type3_Value();
	}
}
