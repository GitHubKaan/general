package fs_string;

import java.text.NumberFormat;
import java.util.Locale;

public class string_format {
	public static void main(String[] args) {
		
		//if you want to put the int/string into a special format
		
		double dBetrag = 1234.56789;
		NumberFormat cf = NumberFormat.getCurrencyInstance();
		System.out.println(cf.format(dBetrag));
		System.out.printf("%,6.2f\t", dBetrag);
		
		
		String msg = String.format(Locale.GERMAN, "Der Preis betr�gt %, 6.2f\n", dBetrag);
		String prozent = String.format (Locale.GERMAN, "%1.0f%%",1.5);
		
		System.out.println(prozent);
	}
}
