package fs_string;

public class stringtointeger
{
	

	public static void main(String[] args)
	{
		String text = "1";
		
		int number = Integer.parseInt(text);
		
		System.out.println(number+number);
	}
}
