package fs_string;

public class substring
{
	public static void main(String[] args)
	{
		String text = "abc";
		String text_poisition_one = "";
		String text_poisition_two = "";
		String text_poisition_three = "";

		//from number position 0 to 1 (first position, f.e. 123 = 1)
		text_poisition_one = text.substring(0, 1);
		System.out.println(text_poisition_one);
		
		//from number position 1 to 2 (second position, f.e. 123 = 2)
		text_poisition_two = text.substring(1, 2);
		System.out.println(text_poisition_two);
		
		//from number position 2 to 3 (third position, f.e. 123 = 3)
		text_poisition_three = text.substring(2, 3);
		System.out.println(text_poisition_three);
	}
}
