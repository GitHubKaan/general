package ss_paint;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class paint {
	public static void main(String[] args) {
		
	}
	
	protected void paintComponent(Graphics g) { //hier m�sste theoretisch eine andere klasse hieraus zugreifen
		JFrame frame = new JFrame();
		frame.setSize(500, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
		JPanel panel = new JPanel();
		frame.add(panel);
		
		Graphics grapic = null;
		panel.paintComponents(grapic);
		
		
		grapic.drawRect(10, 10, 10, 10);
		grapic.setColor(Color.CYAN);
		grapic.fillOval(10, 10, 10, 10);
		grapic.setColor(Color.BLACK);
		grapic.drawLine(10, 10, 10, 10);
		grapic.drawOval(10, 10, 10, 10);
	}
}
