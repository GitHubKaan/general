package fs_general;

public class software_time {
	public static void main(String[] args)
	{
		long startTime = System.currentTimeMillis();

		
		System.out.println("THIS IS A TEXT");
		
		System.out.println("Used time: "+(System.currentTimeMillis()-startTime)+" milliseconds");
	}
}
