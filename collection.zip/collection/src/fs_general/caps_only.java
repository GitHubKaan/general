package fs_general;

public class caps_only {
	public static void main(String[] args)
	{
		//make every string to caps
		String text = "test";
		
		text = text.toUpperCase();
		
		System.out.println(text);
	}
}
