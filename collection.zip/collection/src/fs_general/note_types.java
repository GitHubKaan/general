package fs_general;

public class note_types
{
	//(note line) one line
	//test comment

	//(note line) multiple line
	/*
	 *test comment
	 */

	//(note line) @author line, multiple and one line
	/**
	*@author kaan_turan
	*/
	//@author kaan_turan
}
