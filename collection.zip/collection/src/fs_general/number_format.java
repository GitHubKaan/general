package fs_general;

import java.text.NumberFormat;

public class number_format {
	public static void main(String[] args)
	{
		//change number format
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		System.out.println("Price: " + nf.format(3));
	}
}
