package fs_general;

public class args {
	public static void main(String[] args)
	{
		//args parameter with datatype "String[]"
		//args are a list of strings
		//you can rename "args" in main method to something else
		//"args" only can be strings and nothing else
		
	    double[] ad = new double[args.length];

	    for (int i = 0; i < ad.length; i++) {
	    	ad[i] = Double.parseDouble(args[i]);
	    }
	                        
	    double sum = 0;
	    for (double d : ad) {
	    	sum += d;
	    }
	    
	    System.out.println("Gr\u00f6\u00dfe: " + ad.length);
	    System.out.println("Avarage: " + (sum/ad.length));
	}
}
