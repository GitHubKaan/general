package fs_general;

public class new_class_objects {
		private double kontoStand = 0;
		public double addMoney (double amount) {
		kontoStand += amount;
		return kontoStand;
	}
}
