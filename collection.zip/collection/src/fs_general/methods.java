package fs_general;

import java.util.Scanner;

public class methods {
	
	//methods can be used, if you want to use a calculation for example on a other place in your code
	//Parameter 1, Parameter 2... ==> Method ==> R�ckgabewert
	//methods inside a method is not possible
	
	public static void main(String[] args) {
		Scanner scan = new Scanner (System.in);
		System.out.println("Geben Sie \"N\" ein:");
		int n = scan.nextInt();
		scan.close();
		
		//here you can use your method when ever you want to
		long ergebnis = fakultaet(n);
		System.out.println(n + " != " + ergebnis);
	}
	
	static long fakultaet(int k) {
		long erg = 1;
		for (int i = 2; i <= k; i++)
		erg = erg * i;
		
		return erg;
	}
}
