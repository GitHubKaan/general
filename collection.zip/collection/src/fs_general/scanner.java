package fs_general;

import java.util.Scanner;

public class scanner
{
	public static void main(String[] args)
	{
		/*
		 * scan for syntax in console output
		 * logic:
		 * 		1. create text that is there to enter scanner-text
		 * 		1. create a scanner and scan the entered text
		 * 		3. out print scanned text
		 * 		
		 * 		IMPORTANT:
		 * 		scanner will only stop after user entered something into the console, rest of the code wont work until that
		 */
		//out print text where user can enter f.e.

		//create "Scanner Text:" console message output
		System.out.println("Scanner Text: ");

		//scan user entered text in console
		Scanner scan = new Scanner(System.in);
	
		//change variable (number, or for different (.nextLine())) with scanner output
		//int number = scan.nextInt();
	
		//out print scanned text from console
		System.out.println("You entered the text: " + scan.nextLine());
		//for out print scanned number from console
		//System.out.println("You entered the number: " + scan.nextInt());
	
		//end of the "scanner" method
		scan.close();
	}
}
