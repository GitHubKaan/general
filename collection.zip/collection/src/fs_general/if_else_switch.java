package fs_general;

public class if_else_switch
{
	static int if_statement = 1;
	static int if_statement_second = 5;
	
	static int switch_statement_one = 1;
	static int switch_statement_two = 2;
	
	public static void main(String[] args)
	{
		//if statement
		if (if_statement == 1) {
			if_statement = 2;
			System.out.println("The first 'if_statement' equals: " + if_statement + ".");
		}
		//else if statement inside a if statement
		else if (if_statement == 2) {
			if_statement = 3;
			System.out.println("The first 'if_statement' equals: " + if_statement + ".");
		}
		else if (if_statement == 3) {
			if_statement = 4;
			System.out.println("The first 'if_statement' equals: " + if_statement + ".");
		}

		if (if_statement_second == 1) {
			if_statement_second = 5;
			System.out.println("The second 'if_statement' equals: " + if_statement_second + ".");
		}
		//else statement in the if statement if no statement is true
		else {
			if_statement_second = 10;
			System.out.println("The second 'if_statement' equals: " + if_statement_second + ".");
		}
		
	
		String[] cars = {"Volvo", "BMW", "Ford", "Mazda"};
		for (String i : cars) {
			System.out.print(i + " ");
		}
		
		
		//switch will just jump to the answer given
		switch (switch_statement_one + switch_statement_two) {
		case 1:
			System.out.println("The answer is: 1");
			break;
		case 2:
			System.out.println("The answer is: 2");
			break;
		case 3:
			System.out.println("The answer is: 3");
			break;
		default:
			System.out.println("The answer is: not in the archive");
			break;
		}
	}
}
