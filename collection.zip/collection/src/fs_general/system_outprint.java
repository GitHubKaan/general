package fs_general;

public class system_outprint
{
	static int number_one;
	static int number_two;

	public static void main(String[] args)
	{
		//system out print console types
		System.out.print("print_test");
		System.out.println("println_test");
		System.err.print("errorprint_test");
		System.err.println("errorprintln_test");
	
		//system out print calculation with data types
		System.out.println("calculation: " + number_one + number_two);
	}
}
