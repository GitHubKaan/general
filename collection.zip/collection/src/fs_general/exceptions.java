package fs_general;

import java.io.IOException;

public class exceptions {
	public static void main(String[] args) throws IOException //should cointain "throws IOException", exeption in java means error, IOException means imput output exeption
	{
		//Exceptions are errors causing the software to crash
		try {
			int d = Integer.parseInt("Hello"); //code that contains an error
		} catch (Exception e) { //if errors occure, the software wont crash but do this...
			System.err.println("An error occurred."); //message that gets outprintet if code contains error(s)
		}
	}
}
