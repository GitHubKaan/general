package fs_general;
import java.util.Arrays;

public class matrix_addition {
	public static void main(String[] args)
	{
		//more about it under: E:\archiv_uni\f�cher\Objektorientierte Programmierung I (Gruppe 2)\20.05.2021
		//the code can contain errors because it was made without testing

		final int N = 3;
		
		double[][] a = {
				{0.7, 0.2,0.1},
		        {0.3, 0.6,0.1},
		        {0.5, 0.1,0.4}};
		                
		double[][] b = {
		        {0.8, 0.3,0.5},
		        {0.1, 0.4,0.1},
		        {0.1, 0.3,0.4}};
		                
		double [][] c = new double[N][N];
		                
		
		for (int i = 0; i < 3; i++) {
			for (int j = 0; j < 3; j++) {
				//c[i][j]=a[i][0]*b[0][j] +a[i][1]*b[1][j]+a[i][2]*b[2][j];                        
				for (int k = 0; k < 3; k++) {
					c[i][j] = c[i][j] + (a[i][k] * b[k][j]);    
					/*i=0 j=0 k=0 -> c[0][0]=0+(0.7*0.8)
		              i=0 j=0 k=1 -> c[0][0]=c[0][0]+(a[0][1]*b[1][0])=(0.7*0.8)+(0.2*0.1)
		              i=0 j=0 k=2 -> c[0][0]=c[0][0]+(a[0][2]*b[2][0])=(0.7*0.8)+(0.2*0.1)+(0.1*0.1)
		              i=0 j=1 k=0 -> c[i][j]=c[i][j]+(a[i][k]*b[k][j])
		                                
		              i=0 j=1 k=2 -> c[i][j]=c[i][j]+(a[i][k]*b[k][j]);
		              i=0 j=2 k=0
		                                
		              i=0 j=2 k=2- >c [i][j]=c[i][j]+(a[i][k]*b[k][j]);
		              i=1 j=0 k=0 
		                        
		              1. i=0, j=0, k=0 ==> c[0][0]=c[0][0]+(a[0][0]*b[0][0]);==>(a[0][0]*b[0][0])
		              2. i=0, j=0, k=1 ==> c[0][0]=c[0][0]+(a[0][1]*b[1][0])=(a[0][0]*b[0][0])+(a[0][1]*b[1][0])
		              3. i=0, j=0, k=2 ==> c[0][0]=c[0][0]+(a[0][2]*b[2][0])=(a[0][0]*b[0][0])+(a[0][1]*b[1][0])+(a[0][2]*b[2][0])               
		              4. i=0, j=1, k=0 ==> c[0][1]=c[0][1]+(a[0][0]*b[0][1]);=(a[0][0]*b[0][1])
		              5. i=0, j=1, k=1 ==> c[0][1]=c[0][1]+(a[0][1]*b[1][1])=(a[0][0]*b[0][1])+(a[0][1]*b[1][1])*/
		        }
			}
		    System.out.println(Arrays.toString(c[i]));
		}                
	}
}
