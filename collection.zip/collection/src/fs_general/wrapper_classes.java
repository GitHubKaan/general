package fs_general;

public class wrapper_classes
{
	public static void main(String[] args)
	{
		//##### wrapper #####
		//primitv types
		//byte, short, int, long, float, double, char, boolean
		
		//wrapper class
		//Byte, Short, Integer, Long, Float, Double, Character, Boolean
		
		//example: "Integer" class uses: num = Integer.praseInt(str);
		
		//wrapper class "Integer" contains statistical: MIN_VALUE, MAX_VALUE
		//example 1: MIN_VALUE = smallest integer value (-2147483648)
		//example 2: MAX_VALUE = biggest integer value (2147483648)
		
		
		
		//##### autoboxing #####
		//convert a elementar datatype into datatyp from wrapper class
		Integer obj;
		int num = 10;
		obj = num;
		System.out.println(obj);
	}
}
