package fs_general;

public class concat {
	public static void main(String[] args)
	{
		//extend string with other strings
		String text = "test";
		
		text.concat(", test2");
		
		System.out.println(text);
	}
}
