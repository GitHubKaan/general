package fs_general;

public class objects {
	public static void main(String[] args) {
		//String title; string-variable without content
		
		//title = new String("new_class_objects"); object will be created
		//with this, every method of the entered class (after String) can be used in here
		//f.e. "num Chars = title.lengt();"
		
		//objects are the instances of a class
		//class-parameters with new-instruction a special method of the class that will be opened (konstruktor)
		
		new_class_objects k;
		k = new new_class_objects();
		
		System.out.println(k.addMoney(30));
		System.out.println(k.addMoney(-10));
	}
}
