package fs_general;

import java.util.Random;

public class random {
	public static void main(String[] args)
	{
		System.out.println(Math.random());
		
		int random_test;
		//full random numbers from 0-2
		random_test=(int)(Math.random() * 2);
		//int randomNumber = (int) (Math.random()*(max-min)) + min;
		
		Random random = new Random();
		//random full numbers from 1 to 19
		int n = random.nextInt(1) + 10;
		
		//random full numbers from 10 to 19
		int n2 = random.nextInt(10) + 10;

		//random full numbers from 5 to 19
		int n3 = random.nextInt(15) + 5;

		//random full numbers from -10 to -6
		int n4 = random.nextInt(5) - 10;
		
		//random full numbers from -8 to 0
		int n5 = random.nextInt(9) - 8;
		
		System.out.println(n);
		System.out.println(n2);
		System.out.println(n3);
		System.out.println(n4);
		System.out.println(n5);
	}
}
