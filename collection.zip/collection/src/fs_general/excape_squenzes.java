package fs_general;

public class excape_squenzes {
	// \n new line
	// \t tab symbol
	// \r also new line
	// \" " symbol
	// \' simple " symbol
	// \ \ symbol
}
