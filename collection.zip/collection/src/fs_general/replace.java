package fs_general;

public class replace {
	public static void main(String[] args)
	{
		//change some strings to others
		String text = "replace";
		
		text = text.replace('r', 'L');
		
		System.out.println(text);
	}
}
