package fs_general;

public class loops
{
	static int while_statement_one = 1;
	static int while_statement_two = 0;

	public static void main(String[] args)
	{
		//while statement will go on until it works
		while (while_statement_one < while_statement_two)
		{
			System.out.println("while loop text output");
			break;
		}
			
			
		//do something before request
		do
		{
			System.out.println("do loop text output");
		} while (while_statement_one > while_statement_two);

			
		//for loop is build like given statement:
		//for (Init; Statement; Update) {Request}
		for (int for_statement = 1; for_statement <= 3; for_statement++)
		{
			System.out.println("for loop text output");
		}
	}
}
