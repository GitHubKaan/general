package fs_variables;

public class variables
{
	//different types of data types
	static long long_number = 1;				//long number (-9223372036854775808 to 9223372036854775808)
	static int number = 1;					  	//full number (-2147483648 to 2147483648)
	static short short_number = 1;				//short number (-32768 to 32767)
	static byte byte_number = 1;				//byte (-128 to 127)

	static float float_number = 1.11f;        	//point number (up to 1,79769313486231570)
	static double long_float_number	= 1.11f	;   //point number (up to 3,40282347)				

	static String multiple_text = "aa";			//multiple text strings
	static char letter = 'a';					//single string

	static boolean true_or_false = true;    	//true/false

	static int calculation = number * number; 	//calculation (+, -, *, /)


	//way of using data types in variables
	static double d1 = 1.1, d2 =2.2; 		    //two float numbers
	static double d3 = d1-d2;
	static double d4 = 2*d3;
	static double d5 = d4+0.3;

	//main-method just one in every class
	//where all the code start
	public static void main(String[] args)
	{}
}
