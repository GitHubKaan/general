package fs_variables;

public class change_variable
{
	static int number;
	
	public static void main(String[] args)
	{
		//change value of variable "number"
		number = 1;

		//(variable number increases by +1)
		number++;

		//(variable number decreases by -1)
		number--;

		//out print final number
		System.out.println("f" + "inal variable: " + number);
		
		//variable calculation types and boolien export
		//== 	//two variables equal?
		//< 	//variable smallest than?
		//> 	//variable bigger than?
		//!= 	//variables not equal?
		//<= 	//variable smaller or equal?
		//<= 	//variable bigger or equal?

		//! for negative
		//&& for logical "and"
		//|| for logical "or"
		
		//++ add one (+1)
		//-- delete one (-1)
		//+= add following to number
		//-= delete following to number
	}
}
