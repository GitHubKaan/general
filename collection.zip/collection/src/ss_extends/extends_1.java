package ss_extends;

import java.util.ArrayList;

public class extends_1 {
	public static void main(String[] args) {
		
		ArrayList<String> values = new ArrayList<String>(); //array list for class-connector value
		values.add("value 3");
		
		extends_2 SecondClass = new extends_2("value 1", "value 2", 420, values); //connects this class with "classes_2" and adds values
		
		SecondClass.extends_2_info();
		
		//--------------------------------------------------
		
		extends_3 ThirdClass = new extends_3("info 1", "info 2", 024, values);
	}
}
