package ss_extends;

public abstract class extends_4 { //this is a "abstract class". 
	  							  //abstract classes can not be initiallizised in the main method but they can be used as subclasses/underclasses
	  							  //so this is not possible in main: "classes_4 Forth Class = new classes_4();"
	
	public extends_4() {
		System.out.println("Abstract class, this message wont show up");
	}
}
