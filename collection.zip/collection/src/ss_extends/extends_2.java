package ss_extends;

import java.util.ArrayList;

public class extends_2 { 

	public extends_2(String value1, String value2, int number, ArrayList<String> values) { //all values from "classes_1" will get importet into this part
		System.out.println("value 1: " + value1);
		System.out.println("value 2: " + value2);
		System.out.println("420: " + number);
		System.out.println("value 3: " + values.get(0));
	}

	public void extends_2_info() {
		System.out.println("no infos for \"classes_2\"");
	}

}
