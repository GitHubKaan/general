package ss_extends;

import java.util.ArrayList;

public class extends_3 extends extends_2 { //"extends" means that "classes_3" is now a underclass of "classes_2"

	public ArrayList<String> values_open;
	
	public extends_3(String info1, String info2, int number, ArrayList<String> values) {
		super(info1, info2, number, values); //super means "superclass" it will get the infos from the superclass (classes_2). "classes_2" is the superclass because of "extends classes_2"
											 //the values from "classes_2 -> public classes_2" will get added/edited, non edited values will get importet
		
		this.values_open = values; //to get all the values out of the arraylist and import them into "values_open"
	} 
}
