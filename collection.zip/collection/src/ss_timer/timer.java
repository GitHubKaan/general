package ss_timer;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;


public class timer {
	public static void main(String[] args) {
		JFrame frame = new JFrame(); // frame wird erstellt in der main klasse
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.add(new MainPanel()); // panel ("MainPanel") wird hinzugef�gt
		frame.pack();
		frame.setVisible(true);
	}
}




class MainPanel extends JPanel { // diese klasse f�gt panel hinzu und macht movement
	
	int x = 0;
	int y = 100; //er startet von der y position 100 hierbei
	int counter = 0;

	
	public MainPanel() { // hier ist das Panel
		Timer timer = new Timer(10, new ActionListener() { // timer actionlistener (um so tiefer die zahl desso �fter wird ausgef�hrt)

			@Override
			public void actionPerformed(ActionEvent e) { //action event f�r timer
				
				x += 1; //objekt +1 nach x und y (also rechts unten)
				y += 1;
				
				//um an den rand eines objektes zu sto�en einfach so machen das wenn er der Width enspricht er von + auf - switchen soll
				
				
				repaint(); //hier wird neu gerendert
			}
		});
		
		if (counter == 10) { //er stoppt wenn x bzw. counter = 10 ist
			timer.stop();
		}
		
		timer.start(); //hier springt er wieder zum timer nach oben (actionlistener)
	}

	
	
	
	
	
	@Override
	public Dimension getPreferredSize() { //panel gr��e = frame gr��e (wegen pack bei frame oben, frame umwickelt sich also um das panel)
		return new Dimension(300, 300);
	}

	
	
	
	
	
	@Override
	protected void paintComponent(Graphics g) { //zum zeichen eines objektes (viereck oder dreieck oder soetwas) auf das panel
		super.paintComponent(g); //wird auf die superclasse gepainted
		
		g.drawRect(x, y, 10, 10); //man k�nnte hier auch einen kreis beispielsweise machen (die koordinaten stehen vorne)
	}
	
	
	
	
	
	
	
	
	
	
	
	
}