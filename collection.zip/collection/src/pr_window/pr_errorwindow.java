package pr_window;

import javax.swing.JOptionPane;

public class pr_errorwindow {
	public static void main(String[] args)
	{
		JOptionPane.showMessageDialog(null, "error text window");
	}
}
