package pr_window;

import java.awt.BorderLayout;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class pr_window_1 {
	public static void main(String[] args) {
		
		//> FRAME
		JFrame frame = new JFrame("frame"); //create the frame
	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //what happens when the frame gets closed
		frame.getContentPane().setBackground(Color.DARK_GRAY); //change frame background color. if panel gets addet it will overlay the frame background
		frame.setAlwaysOnTop(true); //force the window to stay always on top
		frame.setTitle("frame"); //set or change frame title
		
		frame.setSize(700, 500); //set the frame size
		frame.setResizable(false); //turn off resizeable window

		frame.setLocation(100, 100); //set frame to a custom location
		frame.setLocationRelativeTo(null); //places frame into the mid of the screen
		
		ImageIcon icon = new ImageIcon("pr_data_window/icon.png"); //import icon image via data or url
		frame.setIconImage(icon.getImage()); //set icon image onto frame
		
		
		
		
		
		//> PANEL
		//one object per panel, not more
		JPanel panel = new JPanel(); //create panel. buttons, textfields... can only be places on panels
		
		panel.setBackground(Color.DARK_GRAY); //set panel color
		panel.setLayout(null); //to move objects on panel freely arround
		panel.setSize(100, 100);
		
		//panels k�nnen paneles k�nnen panels... enthalten
		//immer ein panel verwenden f�r den frame und dann einfach ein panel hinzuf�gen und diesen mit vielen panels austatten
		panel.setLayout(new BorderLayout()); //zum strukturieren des objektes innerhalb des paneles
		JPanel subpanel = new JPanel();
		subpanel.setBackground(Color.RED);
		panel.add(subpanel, BorderLayout.NORTH);

		frame.add(panel); //add panel to frame
		
		
		
		
		
		//> BUTTON
		JButton button = new JButton(); //create button
		
		button.setBounds(0, 0, 50, 50); //position x, y and button size x, y
		
		panel.add(button); //add button to panel
		
		
		
		
		
		//> LABEL
		JLabel label = new JLabel();
		label.setText("label test");
		
		label.setBounds(100, 100, 100, 100);
		
		frame.add(label);
		
		
		
		frame.add(new pr_window_2()); //conect frame to different class
		
		
		
		
		
		//> VISIBILITY
		frame.repaint(); //so werden die objekte neu gerendert
		
		frame.setVisible(true); //set the frame visible, default mode is invisible. always place at end because this is the rendering part
		
		//RENDERING
		//they are different rendering actions
		//rendering can f.e. be used if visibility gets changed
	}
}
