package pr_window;

import javax.swing.JButton;
import javax.swing.JPanel;

public class pr_window_2 extends JPanel { //second panel gets implemented
	
	public pr_window_2() { //frame can be editet here
		JButton button2 = new JButton("second button");
		
		add(button2);
		
		button2.setVisible(true);
	}
}
