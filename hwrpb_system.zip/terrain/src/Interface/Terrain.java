package Interface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Brain.Log;

public class Terrain {
	
	
	//SETTINGS
	static int sizeType = 0; //0 to 5 (higher = more performance needet (if screen is white wait or go down with number))
							 //cooldown will take longer on higher number
	static int firstInfectedAmount = 1; //amount of first infectet
	static int refreshSpeed = 100; //speed of rendering
	
	
	
	static int frameSizeX, frameSizeY;
	static int chunkSize;
	static int totalChunksAtX, totalChunksAtY;
	
	static Log log = new Log();
	
	public Terrain() throws IOException {
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		frameSizeX = (int)(screenSize.getWidth()/2);
		frameSizeY = (int)(screenSize.getHeight()/2);
		
		
		JFrame frame = new JFrame("terrain");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setResizable(false);
		frame.setLayout(null);
		frame.getContentPane().setBackground(Color.DARK_GRAY);
		log.printLog("calculated frame size: "+frameSizeX+"x"+frameSizeY);
		
		
		int chunkCalc = (int)(screenSize.getWidth()*screenSize.getHeight());
		
		int sizeTypeValue = 0;
		if (sizeType == 0) {
			sizeTypeValue = 100000;
		} else if (sizeType == 1) {
			sizeTypeValue = 150000;
		} else if (sizeType == 2) {
			sizeTypeValue = 200000;
		} else if (sizeType == 3) {
			sizeTypeValue = 300000;
		} else if (sizeType == 4) {
			sizeTypeValue = 400000;
		} else if (sizeType == 5) {
			sizeTypeValue = 500000;
		} else {
			log.printLog("wrong size type");
		}
		chunkSize = chunkCalc/sizeTypeValue;
		log.printLog("calculated chunk size: "+chunkSize);
		
		
		totalChunksAtX = frameSizeX/chunkSize;
		totalChunksAtY = frameSizeY/chunkSize;
		log.printLog("tcax: "+totalChunksAtX+", tcay: "+totalChunksAtY);
		int totalChunks = 0;
		totalChunks = totalChunksAtX*totalChunksAtY;
		log.printLog("total chunks: "+totalChunks);
		
		
		int rendeGREENChunkCounter = 0;
		JPanel[] chunkList = new JPanel[totalChunks];	
		for (int i = 0; i < totalChunksAtX; i++) {
			for (int i2 = 0; i2 < totalChunksAtY; i2++) {
				chunkList[rendeGREENChunkCounter] = new JPanel();
				
				chunkList[rendeGREENChunkCounter].setBackground(Color.BLACK);
					
				chunkList[rendeGREENChunkCounter].setBounds(10+(i*chunkSize), 10+(i2*chunkSize), chunkSize, chunkSize);
					
				frame.add(chunkList[rendeGREENChunkCounter]);
					
				rendeGREENChunkCounter++;
			}
		} log.printLog("all chunks rended");
		
		
		frame.setSize(frameSizeX+37, frameSizeY+(60));
		frame.setLocationRelativeTo(null);
		
		int totalRefresh = 100000;
		int sleeper = refreshSpeed;
		int cooldown = 0;
		frame.setVisible(true);
		
		if (sizeType > 3) { //4 or more
			cooldown = 5;
		} else if (sizeType > 1) { //2 or more
			cooldown = 3;
		} else if (sizeType >= 0) { //0 or more
			cooldown = 1;
		} else {
			log.printLog("size type error");
		}

		
		log.printLog("total refresh maximum: "+totalRefresh+", sleeper: "+sleeper);
		int timeLeft = cooldown;
		for (int i = 0; i < cooldown; i++) {
			log.printLog("starting rendering in "+(timeLeft-i)+"...");
			try {
				Thread.sleep((cooldown*1000)/cooldown);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
		
		Color infCol = Color.GREEN;
		
		
		for (int i = 0; i < firstInfectedAmount; i++) {
			int firstInfected = (int)(Math.random()*(totalChunks-0))+0;
			chunkList[firstInfected].setBackground(infCol);
			
			log.printLog("infected spawned at: "+firstInfected);
		}
		
		
		
		log.printLog("====================[STARTING RENDERING]====================");
		for (int i = 0; i < totalRefresh; i++) {
			log.printLog("___| ATTEMPT "+i+" |___");
			log.printLog("trf trys left: "+(totalRefresh-i)+", total: "+totalRefresh);
			
			
			//virus algo start
			
			int totalInfected = 0;
			ArrayList<Integer> infectedPos = new ArrayList<Integer>();
			System.out.print("[ OK ] infected found at: ");
			for (int i2 = 0; i2 < totalChunks; i2++) {
				if (chunkList[i2].getBackground().equals(infCol)) {
					System.out.print(i2 + ", ");
					
					infectedPos.add(i2);
					totalInfected++;
				}
			}
			System.out.println();
			System.out.println("[ OK ] new total infected: "+totalInfected);
			
			int infPosSave = 0;
			for (int allRef = 0; allRef < totalInfected; allRef++) {
				infPosSave = infectedPos.get(allRef);
				
				int bet4 = (int)(Math.random() * 5);
				
				
				if (bet4 == 0) {
					if (infPosSave+1 < totalChunks) {
						int switcher1 = (int)(Math.random() * 2); //0/1
						if (switcher1 == 0) {
							chunkList[infPosSave+1].setBackground(Color.GREEN);
						} else {
							chunkList[infPosSave+1].setBackground(Color.BLACK);
						}
					}
				}
				
				if (bet4 == 1) {
					if (infPosSave-1 < totalChunks && infPosSave-1 > 0) {
						int switcher2 = (int)(Math.random() * 2); //0/1
						if (switcher2 == 0) {
							chunkList[infPosSave-1].setBackground(Color.GREEN);
						} else {
							chunkList[infPosSave-1].setBackground(Color.BLACK);
						}
					}
				}
				
				if (bet4 == 2) {
				if (infPosSave+totalChunksAtY < totalChunks) {
						int switcher3 = (int)(Math.random() * 2); //0/1
						if (switcher3 == 0) {
							chunkList[infPosSave+totalChunksAtY].setBackground(Color.GREEN);
						} else {
							chunkList[infPosSave+totalChunksAtY].setBackground(Color.BLACK);
						}
					}
				}
				
				if (bet4 == 3) {
					if (infPosSave-totalChunksAtY < totalChunks && infPosSave-totalChunksAtY > 0) {
						int switcher4 = (int)(Math.random() * 2); //0/1
						if (switcher4 == 0) {
							chunkList[infPosSave-totalChunksAtY].setBackground(Color.GREEN);
						} else {
							chunkList[infPosSave-totalChunksAtY].setBackground(Color.BLACK);
						}
					}
				}
			}	
			//virus algo end
			
			
		
			frame.setVisible(true);
			
			try {
				Thread.sleep(sleeper);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

	
	
	
	
	
}
