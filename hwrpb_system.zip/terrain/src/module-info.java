module terrain {
	requires java.desktop;
}