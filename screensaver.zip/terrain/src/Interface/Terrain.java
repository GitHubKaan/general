package Interface;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import javax.swing.JFrame;
import javax.swing.JPanel;

import Brain.Log;

public class Terrain {
	
	
	static int randomRisk = (int)(Math.random()*(50-5))+5;
	static int randomSpeed = (int)(Math.random()*(5-3))+3;
	static int randomInfectetAmount = (int)(Math.random()*(30-1))+1;
	
	
	
	
	
	//SETTINGS
	static int sizeType = 2; //0 to 5 (higher = more performance needet (if screen is white wait or go down with number))
							 //cooldown will take longer on higher number
	static int firstInfectedAmount = randomInfectetAmount; //amount of first infectet
	static int refreshSpeed = randomSpeed; //speed of rendering (lower = faster)
	
	static int stopGateActivate = 1; //1 = on/0 = off (if off, simulation will go on for 100.000 max attenpts)
	static int stopGateRisk = randomRisk; //if higher (safer), stop-gate needs longer to detect maximum infections (optimum (safest) 30-100)
								  //to low could stop the simulation at a wrong time
	
	static int turnOffCoolDown = 1; //1 = on/0 = off (can cause problems)
	
	static int megaLooper = 100;
	
	
	
	
	static int frameSizeX, frameSizeY;
	static int chunkSize;
	static int totalChunksAtX, totalChunksAtY;
	
	static Log log = new Log();
	
	public Terrain() throws IOException {
		
		JFrame frame = new JFrame("terrain | mode: " + sizeType + "/5");
		
		for (int megai = 0; megai < megaLooper; megai++) {
			
			randomRisk = (int)(Math.random()*(50-5))+5;
			randomSpeed = (int)(Math.random()*(5-3))+3;
			randomInfectetAmount = (int)(Math.random()*(30-1))+1;
			
			Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
			frameSizeX = (int)(screenSize.getWidth()/2);
			frameSizeY = (int)(screenSize.getHeight()/2);
			
			
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			
			frame.setResizable(false);
			frame.setLayout(null);
			frame.getContentPane().setBackground(Color.DARK_GRAY);
			log.printLog("calculated frame size: "+frameSizeX+"x"+frameSizeY);
			
			if (stopGateActivate == 1) {
				log.printLog("stop-gate is activated");
			} else {
				log.printLog("stop-gate is deactivated");
			}
			
			int chunkCalc = (int)(screenSize.getWidth()*screenSize.getHeight());
			
			int sizeTypeValue = 0;
			if (sizeType == 0) {
				sizeTypeValue = 50000;
			} else if (sizeType == 1) {
				sizeTypeValue = 150000;
			} else if (sizeType == 2) {
				sizeTypeValue = 200000;
			} else if (sizeType == 3) {
				sizeTypeValue = 300000;
			} else if (sizeType == 4) {
				sizeTypeValue = 450000;
			} else if (sizeType == 5) {
				sizeTypeValue = 700000;
			} else {
				log.printLog("wrong size type");
			}
			chunkSize = chunkCalc/sizeTypeValue;
			log.printLog("calculated chunk size: "+chunkSize);
			
			
			totalChunksAtX = frameSizeX/chunkSize;
			totalChunksAtY = frameSizeY/chunkSize;
			log.printLog("tcax: "+totalChunksAtX+", tcay: "+totalChunksAtY);
			int totalChunks = 0;
			totalChunks = totalChunksAtX*totalChunksAtY;
			log.printLog("total chunks: "+totalChunks);
			
			
			int randomColor = (int)(Math.random()*(8-0))+0;
			Color finalColor = Color.WHITE;
			if (randomColor == 0) {
				finalColor = Color.RED;
			} else if (randomColor == 1) {
				finalColor = Color.BLUE;
			} else if (randomColor == 2) {
				finalColor = Color.GREEN;
			} else if (randomColor == 3) {
				finalColor = Color.YELLOW;
			} else if (randomColor == 4) {
				finalColor = Color.PINK;
			} else if (randomColor == 5) {
				finalColor = Color.CYAN;
			} else if (randomColor == 6) {
				finalColor = Color.MAGENTA;
			}
			int randomColor2 = (int)(Math.random()*(8-0))+0;
			Color finalColor2 = Color.WHITE;
			if (randomColor2 == 0) {
				finalColor2 = Color.RED;
			} else if (randomColor2 == 1) {
				finalColor2 = Color.BLUE;
			} else if (randomColor2 == 2) {
				finalColor2 = Color.GREEN;
			} else if (randomColor2 == 3) {
				finalColor2 = Color.YELLOW;
			} else if (randomColor2 == 4) {
				finalColor2 = Color.PINK;
			} else if (randomColor2 == 5) {
				finalColor2 = Color.CYAN;
			} else if (randomColor2 == 6) {
				finalColor2 = Color.MAGENTA;
			}
			
			int rendedChunkCounter = 0;
			JPanel[] chunkList = new JPanel[totalChunks];
			
			for (int i = 0; i < totalChunksAtX; i++) {
				for (int i2 = 0; i2 < totalChunksAtY; i2++) {
					chunkList[rendedChunkCounter] = new JPanel();
					
					chunkList[rendedChunkCounter].setBackground(Color.BLACK);
						
					chunkList[rendedChunkCounter].setBounds(10+(i*chunkSize), 10+(i2*chunkSize), chunkSize, chunkSize);
						
					frame.add(chunkList[rendedChunkCounter]);
						
					rendedChunkCounter++;
				}
			} log.printLog("all chunks rended");
			
			
			frame.setSize(frameSizeX+37, frameSizeY+(60));
			frame.setLocationRelativeTo(null);
			
			int totalRefresh = 100000;
			int sleeper = refreshSpeed;
			int cooldown = 0;
			frame.setVisible(true);
			
			if (sizeType > 3) { //4 or more
				cooldown = 10;
			} else if (sizeType > 1) { //2 or more
				cooldown = 3;
			} else if (sizeType >= 0) { //0 or more
				cooldown = 1;
			} else {
				log.printLog("size type error");
			}
			if (turnOffCoolDown == 1) {
				cooldown = 0;
			}
			
			log.printLog("total refresh maximum: "+totalRefresh+", sleeper: "+sleeper);
			int timeLeft = cooldown;
			for (int i = 0; i < cooldown; i++) {
				log.printLog("starting rendering in "+(timeLeft-i)+"...");
				try {
					Thread.sleep((cooldown*1000)/cooldown);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			
			
			Color infCol = finalColor;
			
			
			for (int i = 0; i < firstInfectedAmount; i++) {
				int firstInfected = (int)(Math.random()*(totalChunks-0))+0;
				chunkList[firstInfected].setBackground(infCol);
				
				log.printLog("infected spawned at: "+firstInfected);
			}
			
			int breaker = 0;
			double StopGate1 = 0;
			double StopGate2 = 0;
			ArrayList<Integer> autoStopperList = new ArrayList<Integer>();
			log.printLog("====================[STARTING RENDERING]====================");
			for (int i = 0; i < totalRefresh; i++) {
				log.printLog("___| ATTEMPT "+i+" |___");
				log.printLog("trf trys left: "+(totalRefresh-i));
				
				
				//virus algo start
				
				int totalInfected = 0;
				ArrayList<Integer> infectedPos = new ArrayList<Integer>();
				System.out.print("[ OK ] infected found at: ");
				for (int i2 = 0; i2 < totalChunks; i2++) {
					if (chunkList[i2].getBackground().equals(infCol)) {
						System.out.print(i2 + ", ");
						
						infectedPos.add(i2);
						totalInfected++;
					}
				}
				System.out.println();
				double percCalc = ((double)totalInfected/(double)totalChunks)*100;
				DecimalFormat numberFormat = new DecimalFormat("0.00");
				System.out.println("[ OK ] new total infected: "+totalInfected+", from total chunks: "+totalChunks+" -> in percent: "+numberFormat.format(percCalc)+"%");
				
				
				if (stopGateActivate == 1) {
					//auto stopper algo
					autoStopperList.add((int)percCalc);
					if (autoStopperList.size() > stopGateRisk-1) {
						int summer = 0;
						int summerFinal = 0;
						for (int i2 = 0; i2 < autoStopperList.size(); i2++) {
							summer += autoStopperList.get(i2);
						}
						summerFinal = summer/stopGateRisk;
						
						if (StopGate1 == 0) {
							StopGate1 = summerFinal;
						} else if (StopGate2 == 0) {
							StopGate2 = summerFinal;
							
							if (StopGate1-StopGate2 == 0) {
								log.printLog("stop-gate difference found at: "+StopGate1 + " : " + StopGate2 + ", for risk: "+stopGateRisk);
								log.printLog("auto stopper activated -> exit simulation...");
								breaker = 1;
								break;
							}
							
							
							StopGate1 = 0;
							StopGate2 = 0;
						}
						
						summer = 0;
						autoStopperList.clear();
					}
					
					if (breaker == 1) {
						break;
					}
				}
				
				int infPosSave = 0;
				for (int allRef = 0; allRef < totalInfected; allRef++) {
					
					infPosSave = infectedPos.get(allRef);
					
					int bet4 = (int)(Math.random() * 5);
					
					
					if (bet4 == 0) {
						if (infPosSave+1 < totalChunks) {
							int switcher1 = (int)(Math.random() * 2); //0/1
							if (switcher1 == 0) {
								chunkList[infPosSave+1].setBackground(finalColor2);
							} else {
								chunkList[infPosSave+1].setBackground(Color.BLACK);
							}
						}
					}
					
					if (bet4 == 1) {
						if (infPosSave-1 < totalChunks && infPosSave-1 > 0) {
							int switcher2 = (int)(Math.random() * 2); //0/1
							if (switcher2 == 0) {
								chunkList[infPosSave-1].setBackground(finalColor);
							} else {
								chunkList[infPosSave-1].setBackground(Color.BLACK);
							}
						}
					}
					
					if (bet4 == 2) {
					if (infPosSave+totalChunksAtY < totalChunks) {
							int switcher3 = (int)(Math.random() * 2); //0/1
							if (switcher3 == 0) {
								chunkList[infPosSave+totalChunksAtY].setBackground(finalColor2);
							} else {
								chunkList[infPosSave+totalChunksAtY].setBackground(Color.BLACK);
							}
						}
					}
					
					if (bet4 == 3) {
						if (infPosSave-totalChunksAtY < totalChunks && infPosSave-totalChunksAtY > 0) {
							int switcher4 = (int)(Math.random() * 2); //0/1
							if (switcher4 == 0) {
								chunkList[infPosSave-totalChunksAtY].setBackground(finalColor);
							} else {
								chunkList[infPosSave-totalChunksAtY].setBackground(Color.BLACK);
							}
						}
					}
				}	
				//virus algo end
				
				
			
				frame.setVisible(true);
				
				try {
					Thread.sleep(sleeper);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
			for (int i = 0; i < chunkList.length; i++) {
				chunkList[i].setBackground(Color.BLACK);
			}
			
		}
	}
	
}
