package Brain;

import java.io.IOException;
import Interface.Terrain;

public class Main {
	public static void main(String[] args) throws IOException {
		System.out.println("[ OK ] starting software (optimized for windows 10)...");
		
		Terrain frameClass = new Terrain();
	}
}
