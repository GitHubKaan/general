package Brain;

public class Log {
	public void printLog(String p) {
		System.out.println("[ OK ] " + p);
	}
}
